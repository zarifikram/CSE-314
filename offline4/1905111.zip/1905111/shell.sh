# g++ -pthread exampleCodes/prod_cons_without_mutex.cpp 
g++ -pthread ./1905111.cpp 
./a.out